#
# TABLE STRUCTURE FOR: tbl_art
#

DROP TABLE IF EXISTS tbl_art;

CREATE TABLE `tbl_art` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

